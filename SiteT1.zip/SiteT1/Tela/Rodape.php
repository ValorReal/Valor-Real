<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="inicial.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela Final</title>
    <link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<body>
    <div id="css/inicial">
    </div>
<footer>
<main class="profile">
  <div class="profile-bg"></div>
  <section class="container">
    <aside class="profile-image">
      </a>
    </aside>

    <section class="profile-info">
      <h1 class="first-name">Turma</h1>
      <h1 class="second-name">1</h1>
      <h2> A Turma que Marcou História</h2>
      <p>
      Texto da Turma 
      </p>
</footer>
</body>
</html>